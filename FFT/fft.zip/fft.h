

extern void cfft(float x[], int  NC, int forward) ;

extern void rfft(float x[], int  N, int forward) ;


